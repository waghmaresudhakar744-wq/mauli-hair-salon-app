माऊली हेअर सलून Android APK प्रकल्प

मोबाईलवरून APK तयार करण्यासाठी:
1. GitHub खाते तयार/लॉगिन करा.
2. New repository तयार करा. नाव: mauli-hair-salon-app
3. Repository Public निवडा (मोफत GitHub Actions वापरण्यासाठी सोपे) किंवा तुमच्या खात्याच्या उपलब्ध Actions मर्यादा तपासा.
4. या ZIP मधील MauliHairSalonAndroid फोल्डरमधील सर्व फाइल्स व .github फोल्डर repository च्या मुख्य पातळीवर अपलोड करा.
5. Commit changes करा.
6. Actions टॅब उघडा > Build Mauli Hair Salon APK > Run workflow.
7. Build पूर्ण झाल्यावर workflow run उघडा. Artifacts मधील Mauli-Hair-Salon-APK डाउनलोड करा.
8. ZIP उघडून app-debug.apk मोबाईलवर इन्स्टॉल करा.

महत्त्वाचे:
- हा debug APK आहे; वैयक्तिक चाचणी/थेट शेअरिंगसाठी. Play Store प्रकाशनासाठी वेगळी signed release प्रक्रिया लागेल.
- APK वेबसाइट https://maulihairsalon2026.pages.dev/ WebView मध्ये उघडतो. वेबसाइटमधील ग्राहक बुकिंग आणि मालक PIN सुविधा कार्यरत असणे आवश्यक आहे.
- कोणताही OTP समाविष्ट केलेला नाही.
- मालकाचा PIN, GitHub password किंवा token कोणालाही पाठवू नका.
- आधीच्या Cloudflare D1 डेटाबेसमध्ये या प्रकल्पामुळे कोणताही बदल होत नाही.
