माऊली हेअर सलून – GitHub APK Build (दुरुस्त प्रकल्प)

महत्त्वाचे: ZIP थेट GitHub वर अपलोड करू नका.
1. ZIP मोबाईलमध्ये Extract करा.
2. Extract केलेल्या फोल्डरमधील सर्व फाईल्स आणि .github फोल्डर निवडा.
3. GitHub repository च्या मुख्य पानावर (root) या सर्व फाईल्स अपलोड करा.
   app, .github, build.gradle.kts, settings.gradle.kts, gradle.properties हे root मध्ये दिसले पाहिजेत.
4. .github/workflows/build-apk.yml ही workflow फाईल त्याच जागी असली पाहिजे.
5. Commit करा. Actions > Build Mauli Hair Salon APK > Run workflow.
6. हिरवा Build झाल्यावर Artifacts मधील Mauli-Hair-Salon-APK डाउनलोड करा.
7. APK debug आहे; चाचणीसाठी थेट install करता येईल. Play Store साठी signed release आवश्यक.

या प्रकल्पात वेबसाइट https://maulihairsalon2026.pages.dev/ WebView मध्ये उघडते.
Cloudflare D1 डेटाबेसला बदलत नाही. OTP नाही. मालकाचा PIN code मध्ये ठेवू नका.
